package com.coforge.service;

import com.coforge.model.Claim;
import com.coforge.model.InsurancePolicy;
import com.coforge.repository.ClaimRepository;
import com.coforge.repository.InsuranceRepository;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InsuranceService {
    @Autowired
    private InsuranceRepository insuranceRepository;

    @Autowired
    private ClaimRepository claimRepository;

    public InsurancePolicy buyInsurance(InsurancePolicy policy) {
        policy.setPolicyNumber(UUID.randomUUID().toString());
        return insuranceRepository.save(policy);
    }

    public InsurancePolicy renewInsurance(String policyNumber) {
        InsurancePolicy policy = insuranceRepository.findByPolicyNumber(policyNumber);
        if (policy != null) {
            policy.setRenewed(true);
            return insuranceRepository.save(policy);
        }
        return null;
    }


    public double calculateInsuranceEstimate(String type, String vehicleModel) {
        double basePrice;
        double modelFactor;

        // Example logic for estimation
        if (type.equalsIgnoreCase("Car")) {
            basePrice = 8000;
            modelFactor = vehicleModel.equalsIgnoreCase("luxury") ? 1.5 : 1.0;
        } else if (type.equalsIgnoreCase("Travel")) {
            basePrice = 3000;
            modelFactor = vehicleModel.equalsIgnoreCase("international") ? 1.2 : 1.0;
        }
        else if (type.equalsIgnoreCase("Bike")) {
            basePrice = 1500;
            modelFactor = vehicleModel.equalsIgnoreCase("sport") ? 1.2 : 1.0;
        }
        else if (type.equalsIgnoreCase("Truck")) {
            basePrice = 10000;
            modelFactor = vehicleModel.equalsIgnoreCase("National-Permit") ? 1.2 : 1.0;
        }
        else if (type.equalsIgnoreCase("E-Rickshaw")) {
            basePrice = 2500;
            modelFactor = vehicleModel.equalsIgnoreCase("Modern") ? 1.2 : 1.0;
        }else {
            basePrice = 2000; // Default base price for unknown types
            modelFactor = 1.25;
        }

        return basePrice * modelFactor;
    }

    public Claim claimInsurance(Claim claim) {
        // Retrieve the insurance policy using the policy number
        InsurancePolicy policy = insuranceRepository.findByPolicyNumber(claim.getPolicyNumber());
        
        if (policy != null) {
            // Approve the claim if the claim amount is less than or equal to the premium amount
            if (claim.getClaimAmount() <= 5 * policy.getPremiumAmount()) {
                claim.setApproved(true);
            } else {
                claim.setApproved(false);
            }
        } else {
            throw new RuntimeException("Policy not found");
        }
        
        return claimRepository.save(claim);
    }

    public Claim getClaimStatus(String policyNumber) {
        return claimRepository.findByPolicyNumber(policyNumber);
    }

    public Claim approveClaim(Long claimId) {
        Claim claim = claimRepository.findById(claimId).orElseThrow(() -> new RuntimeException("Claim not found"));
        claim.setApproved(true);
        return claimRepository.save(claim);
    }
}