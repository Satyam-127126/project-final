package com.coforge.service;

import com.coforge.model.User;
import com.coforge.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) {
        return userRepository.save(user);
    }

    public User loginUser(String username, String password) {
        User user = userRepository.findByUsername(username);
        if (user != null) {
            if (user.getPassword().equals(password)) {
                return user;
            } else {
                System.out.println("Invalid Credentials");
            }
        } else {
            System.out.println("User not found");
        }
        return null;
    }
}