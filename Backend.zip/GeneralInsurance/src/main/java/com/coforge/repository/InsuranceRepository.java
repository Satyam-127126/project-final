package com.coforge.repository;

import com.coforge.model.InsurancePolicy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InsuranceRepository extends JpaRepository<InsurancePolicy, Long> {
    InsurancePolicy findByPolicyNumber(String policyNumber);
}