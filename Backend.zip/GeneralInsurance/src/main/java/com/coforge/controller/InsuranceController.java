package com.coforge.controller;


import com.coforge.model.Claim;
import com.coforge.model.InsurancePolicy;
import com.coforge.service.InsuranceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/insurance")
public class InsuranceController {
    @Autowired
    private InsuranceService insuranceService;

    @PostMapping("/buy")
    public InsurancePolicy buyInsurance(@RequestBody InsurancePolicy policy) {
        return insuranceService.buyInsurance(policy);
    }

    @PostMapping("/renew")
    public InsurancePolicy renewInsurance(@RequestParam String policyNumber) {
        return insuranceService.renewInsurance(policyNumber);
    }

    @GetMapping("/estimate")
    public double estimateInsurance(@RequestParam String type, @RequestParam String vehicleModel) {
        return insuranceService.calculateInsuranceEstimate(type, vehicleModel);
    }

    @PostMapping("/claim")
    public Claim claimInsurance(@RequestBody Claim claim) {
        return insuranceService.claimInsurance(claim);
    }

    @GetMapping("/claim/status")
    public Claim getClaimStatus(@RequestParam String policyNumber) {
        return insuranceService.getClaimStatus(policyNumber);
    }

    @PostMapping("/claim/approve")
    public Claim approveClaim(@RequestParam Long claimId) {
        return insuranceService.approveClaim(claimId);
    }
}